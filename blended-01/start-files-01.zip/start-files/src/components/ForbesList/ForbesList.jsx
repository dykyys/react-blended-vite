export const ForbesList = () => {
  return <h2>ForbesList</h2>;
};
