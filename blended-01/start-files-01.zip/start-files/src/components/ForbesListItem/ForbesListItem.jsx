// import { BiDollarCircle } from 'react-icons/bi';
// import { FcBullish, FcBearish } from 'react-icons/fc';

export const ForbesListItem = () => {
  return <h3>ForbesListItem</h3>;
};
