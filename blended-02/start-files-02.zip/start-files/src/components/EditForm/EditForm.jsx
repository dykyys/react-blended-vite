// import { RiSaveLine } from 'react-icons/ri';
// import { MdOutlineCancel } from 'react-icons/md';

export const EditForm = () => {
  return <h2>EditForm</h2>;
};
