// import { FiSearch } from 'react-icons/fi';

export const Form = () => {
  return <h2>Form</h2>;
};
