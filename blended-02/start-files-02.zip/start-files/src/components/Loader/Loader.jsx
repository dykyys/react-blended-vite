export const Loader = () => {
  return <div>Loader</div>;
};
