export const PhotosGallery = () => {
  return <h3>PhotosGallery</h3>;
};
