// import { getPhotos } from 'apiService/photos';
import { Text } from 'components';

export const Photos = () => {
  return (
    <>
      <Text textAlign="center">Let`s begin search 🔎</Text>
    </>
  );
};
