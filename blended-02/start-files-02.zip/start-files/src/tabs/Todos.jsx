import { Text } from 'components';

export const Todos = () => {
  return <Text textAlign="center">There are no any todos ...</Text>;
};
