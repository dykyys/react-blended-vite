// import { FiSearch } from 'react-icons/fi';

//const regions = [
//   { id: 'africa', value: 'africa', name: 'Africa' },
//   { id: 'americas', value: 'americas', name: 'America' },
//   { id: 'asia', value: 'asia', name: 'Asia' },
//   { id: 'europe', value: 'europe', name: 'Europe' },
//   { id: 'oceania', value: 'oceania', name: 'Oceania' },
// ];

export const SearchForm = () => {
  return <h2>SearchForm</h2>;
};
