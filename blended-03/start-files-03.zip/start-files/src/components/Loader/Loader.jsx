export const Loader = () => {
  return <h2>Loader</h2>;
};
