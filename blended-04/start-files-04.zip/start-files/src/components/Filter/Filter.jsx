import style from './Filter.module.css';

export const Filter = () => {
  return <input className={style.input} placeholder="Find it" name="filter" />;
};
