import { Text } from 'components';

export const Todo = () => {
  return (
    <Text textAlign="center" marginBottom="20">
      TODO #
    </Text>
  );
};
