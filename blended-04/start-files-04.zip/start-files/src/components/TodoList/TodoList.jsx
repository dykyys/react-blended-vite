import { Text } from 'components';

export const TodoList = () => {
  return (
    <>
      <Text textAlign="center">We did not find any todo😯</Text>
    </>
  );
};
