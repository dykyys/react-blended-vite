export const routes = {
  HOME: '/',
  OPTIONS: '/options',
};
