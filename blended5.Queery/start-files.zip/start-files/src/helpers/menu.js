import { routes } from '../routes';

export const menu = [
  { id: 'home', name: 'home', path: routes.HOME },
  { id: 'options', name: 'options', path: routes.OPTIONS },
];
