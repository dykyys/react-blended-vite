export const PhotosGalleryItem = () => {
  return <h3>PhotosGalleryItem</h3>;
};
