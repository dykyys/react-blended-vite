// import { useState, useEffect } from 'react';

export const useLocalStorage = () => {
  // Тут повинен бути власний хук для збереження і отримання даних з localStorage
  // Даний хук повинен отримувати key, defaultValue і повертати дані з localStorage
  //якщо дані були збережені
  //якщо в localStorage не були збережені дані з ключом key, то хук повинен повертати defaultValue
};
